package AccessModifiers;

public class Private1 {
	
	private void display()
		{
			System.out.println("TNS Sessions");
			
		}
	}


