package AccessModifiers;

public class Public1 {
	public void display() {
	System.out.println("bb");
	}
	

}
