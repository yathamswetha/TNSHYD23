package oop;

public class Main3getterssettersAddfunctionality {
	public static void main(String[] args) {
		Student3getterssettersAddfunctionality Student = new Student3getterssettersAddfunctionality();
		Student.setAge (21);
		Student.setName ("SWETHA");
		Student.setId ("64");
		Student.setAddress ("B.N reddy");
		//calling the function
		System.out.println (Student.run ());
	}

}


