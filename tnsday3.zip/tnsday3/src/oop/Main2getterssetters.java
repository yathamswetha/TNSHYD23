package oop;

public class Main2getterssetters {
	public static void main(String[] args) {
		 Student2gettersseeters s2= new  Student2gettersseeters();
		s2.setAge(20);
		System.out.println(s2.getAge());
		s2.setName("Swetha");
		System.out.println(s2.getName());
		
		
	}

}
