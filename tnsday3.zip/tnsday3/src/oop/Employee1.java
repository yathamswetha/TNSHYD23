

package oop;

public class Employee1 {
	
	private int Id;
	private String Name;
	private int Salary;
	public int getId() {
		return Id;
	}
	public void setId(int id) {
		Id = id;
	}
	
	
}
