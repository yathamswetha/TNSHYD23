package oop;

public class MainEmployee1 {
	public static void main(String[] args) {
		Employee1 e1= new Employee1();
		e1.setId(20);
		System.out.println(e1.getId());
	}

}
