package oop;

public class Student2gettersseeters {
	private String name;
	private String address;
	private int age;
	private int id;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public int getid() {
		return id;
	}
	public void setid(int id) {
		this.id = id;
	}
	

}




