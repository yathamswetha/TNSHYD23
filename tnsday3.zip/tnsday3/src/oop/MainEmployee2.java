package oop;
public class MainEmployee2 {
	public static void main(String[] args) {
		 Employee2 e2= new  Employee2();
		e2.setId(30);
		System.out.println(e2.getId());
		
		
		e2.setName("Thrisha");
		System.out.println(e2.getName());
		
		
	}

}
