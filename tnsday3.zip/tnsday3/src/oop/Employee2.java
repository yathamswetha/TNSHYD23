


package oop;

public class Employee2 {
	
	private int Id;
	private String Name;
	private int Salary;
	
	public int getId() {
		return Id;
	}
	public void setId(int Id) {
		this.Id = Id;
	}
	public String getName() {
		return Name;
	}
	public void setName(String Name) {
		this.Name = Name;
	}
	public int getSalary() {
		return Salary;
	}
	public void set(int Salary) {
		this.Salary = Salary;
	}
	
	

}
