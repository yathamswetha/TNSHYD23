package Accessmodifiers2;
import  AccessModifiers.*;
public class default2 {
	public static void main(String[] args) {
		Default1 obj=new Default1();
		obj.display();
		
	}
	}
	
	
		
	
	


