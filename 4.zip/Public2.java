package Accessmodifiers2;
import AccessModifiers.*;
public class Public2 {
	public static void main(String[] args) {
		Public1 obj=new Public1();
		obj.display();
	}

}
