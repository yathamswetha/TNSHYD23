package com.methods;

public class MethodwithParameterNoReturnType2 {
	
	public static void main(String[] args) {
		System.out.println("Area of Reactangle with length=5.4" + "and width =3.2");
		areaReactangle(5.4,3.2);
	}

	public static void areaReactangle(double length, double width) {
		// TODO Auto-generated method stub
		
		System.out.println(length*width);
		
	}

}
