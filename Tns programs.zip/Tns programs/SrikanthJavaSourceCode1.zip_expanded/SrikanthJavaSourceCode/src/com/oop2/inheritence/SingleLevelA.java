package com.oop2.inheritence;

public class SingleLevelA {
	
	public void display() {
		System.out.println("I am a method from class A");
	}

}
