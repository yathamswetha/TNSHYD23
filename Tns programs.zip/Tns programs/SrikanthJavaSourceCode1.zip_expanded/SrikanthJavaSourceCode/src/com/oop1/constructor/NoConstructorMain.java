package com.oop1.constructor;

public class NoConstructorMain {
	
	public static void main(String[] args) {
		NoConstructor n1 = new NoConstructor();
		System.out.println(n1.getBrand());
	}

}
