package com.oop1.constructor;

public class NoConstructor {
	
	private String brand = "samsung";
	
	public String getBrand() {
		return brand;
	}

}
