package com.coreconcepts.accessmodifiers;

public class DefaultA {
	
	void display() {
		System.out.println("TNS sessions");
	}

}
