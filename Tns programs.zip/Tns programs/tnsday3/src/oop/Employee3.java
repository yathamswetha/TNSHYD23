package oop;

public class Employee3 {
	
	private int Id;
	private String Name;
	private int Salary;
	
	
	public int getId() {
		return Id;
	}
	public void setId(int Id) {
		this.Id = Id;
	}
	public String getName() {
		return Name;
	}
	public void setName(String Name) {
		this.Name = Name;
	}
	public int getSalary() {
		return Salary;
	}
	public void setSalary(int Salary) {
		this.Salary = Salary;
	}
		
	public String Working() {
		if(Id>1 && Name.equals("Swetha")&& Salary>10) 
				 {
			return "Employee is working";
		}else {
			return "Employee is not working";
		}

}
}
