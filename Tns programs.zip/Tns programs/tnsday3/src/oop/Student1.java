package oop;

public class Student1 {
	private String name;
	private String address;
	private String id;
	public int age ;
	
}


