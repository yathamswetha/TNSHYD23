package oop;

public class Main1 {
	public static void main(String[] args) {
		Student1 s1= new Student1();
		s1.age=21;
		System.out.println(s1.age);
	}

}



