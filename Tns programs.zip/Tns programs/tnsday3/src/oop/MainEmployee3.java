package oop;



public class MainEmployee3 {
	public static void main(String[] args) {
		Employee3 e3 = new Employee3 ();
		e3.setId (10);
		e3.setName ("Swetha");
		e3.setSalary (20);
		
		//calling the function
		System.out.println (e3.Working ());
	}


}
