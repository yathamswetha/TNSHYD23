package Accessmodifiers2;
import AccessModifiers.*;
public class protected2 extends protected1{
	public static void main(String[] args) {
		 protected2 obj=new  protected2();
		 obj.display();
		 
	}
	

}
