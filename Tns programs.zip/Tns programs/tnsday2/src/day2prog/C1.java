package day2prog;

public class C1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
				C x1=new C();
				System.out.println(x1.x);
				System.out.println(C.y);
				x1.display();
				C.display1();
				
			}

			
			

		

	}


