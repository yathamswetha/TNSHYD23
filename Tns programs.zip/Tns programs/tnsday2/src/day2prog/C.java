package day2prog;

public class C {
	int x=20;
	static int  y=40;
	public void display() {
		System.out.println("aa");
	
	}
	static void display1()
	{
		System.out.println("10");
	
	}
	
	
}

