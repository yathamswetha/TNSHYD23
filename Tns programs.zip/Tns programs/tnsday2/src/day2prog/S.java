package day2prog;
class A{
	int a=20;
	static int c=30;
	void display(){
		}
static void display1() {
}
public static void main(String[] args) {
	A a1 = new A();
	System.out.println(A.c);
	System.out.println(a1.a);
	a1.display();
	A.display1();
}
}