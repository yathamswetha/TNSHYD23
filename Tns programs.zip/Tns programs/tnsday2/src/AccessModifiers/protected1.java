package AccessModifiers;

public class protected1 {
	protected void display() {
		System.out.println("aa");
		
	
		

	}

}
