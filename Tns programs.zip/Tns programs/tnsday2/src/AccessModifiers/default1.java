package AccessModifiers;

public class default1 {
	void display() {
		System.out.println("Hello World!");
		
		
	}
	

}
