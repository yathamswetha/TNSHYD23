package AccessModifiers;

public class Private2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 Private1 obj=new  Private1();
		obj.display();

	}

}
	